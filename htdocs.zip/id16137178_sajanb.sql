-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 02, 2021 at 06:28 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id16137178_sajanb`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `b_id` int(10) NOT NULL,
  `b_date` date NOT NULL,
  `b_status` varchar(30) NOT NULL,
  `b_check_in_date` date NOT NULL,
  `b_check_out_date` date NOT NULL,
  `no_of_guests` int(10) NOT NULL,
  `contact_no` int(20) NOT NULL,
  `r_id` int(23) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `b_date`, `b_status`, `b_check_in_date`, `b_check_out_date`, `no_of_guests`, `contact_no`, `r_id`) VALUES
(10, '2021-04-28', 'Booked', '2021-04-28', '2021-04-29', 2, 714409563, 9);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `contact_no` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `country` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`contact_no`, `name`, `address`, `email`, `country`, `password`) VALUES
(714409563, 'AAA', '123123', 'sajanvishes@gmail.com', 'Erab', 'sajan123'),
(710958145, 'Anushka', 'piliyandala', 'sajanvishes@gmail.com', 'Sri Lanka', 'Sajan123');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_no` int(5) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(200) NOT NULL,
  `contact_no` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_no`, `date`, `description`, `contact_no`) VALUES
(3, '2019-02-23', 'good job', 716352568),
(4, '2020-01-09', 'The hotel was very clean and the room service was excellent.', 125478952),
(5, '2020-01-22', 'nice hotel', 754123652),
(6, '2020-01-23', 'Room funiture very comfortable and modern.', 155274859),
(7, '2020-01-15', 'nice!!!!', 642578563),
(8, '2020-01-31', 'Breakfast was very good and the choice of various foods was appreciated.', 642857365);

-- --------------------------------------------------------

--
-- Table structure for table `food_items`
--

CREATE TABLE `food_items` (
  `i_id` int(12) NOT NULL,
  `item_name` varchar(40) NOT NULL,
  `item_description` varchar(50) NOT NULL,
  `item_price` decimal(12,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_items`
--

INSERT INTO `food_items` (`i_id`, `item_name`, `item_description`, `item_price`) VALUES
(1, 'Burger', 'taste', 230),
(2, 'French Fries', 'Fried crispy fries', 300),
(3, 'Spagetti', 'Spicy roast chicken flavored spagetti ', 500),
(4, 'Fresh Food Salad', 'One pack', 250),
(5, 'Sea food rice', 'rice with associated sea food', 650),
(6, 'Fried rice', 'mixed with  eggs, vegetables, seafood, meat.', 980),
(7, 'rice', 'breakfast', 200);

-- --------------------------------------------------------

--
-- Table structure for table `food_order`
--

CREATE TABLE `food_order` (
  `o_id` int(10) NOT NULL,
  `o_date` varchar(15) NOT NULL,
  `o_status` varchar(100) NOT NULL,
  `amount` float NOT NULL,
  `contact_no` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_order`
--

INSERT INTO `food_order` (`o_id`, `o_date`, `o_status`, `amount`, `contact_no`) VALUES
(1, '2020-01-18', 'Delivered', 230, '716352568'),
(2, '2020-01-22', 'Deliverd', 650, '718273633'),
(3, '2020-01-25', 'Deliverd', 650, '703454453'),
(4, '2020-01-30', 'Deliverd', 1600, '642857365');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `method` varchar(20) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `b_id` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `date`, `method`, `amount`, `b_id`) VALUES
(1, '2020-01-01', 'Cash', 13500, '1'),
(2, '2020-01-22', 'Cash', 4500, '2'),
(3, '2020-01-29', 'Cash', 3500, '3'),
(4, '2020-01-31', 'Visa', 13500, '4');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `r_id` int(12) NOT NULL,
  `r_name` varchar(30) NOT NULL,
  `beds` varchar(20) NOT NULL,
  `tv` varchar(20) NOT NULL,
  `ac` varchar(10) NOT NULL,
  `minibar` varchar(12) NOT NULL,
  `hotwater` varchar(10) NOT NULL,
  `coffee` varchar(10) NOT NULL,
  `price` decimal(30,0) NOT NULL,
  `availability` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`r_id`, `r_name`, `beds`, `tv`, `ac`, `minibar`, `hotwater`, `coffee`, `price`, `availability`) VALUES
(1, 'Luxury', '4', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 13500, 'No'),
(2, 'Semi', '2', 'Yes', 'Yes', 'No', 'Yes', 'No', 4500, 'Yes'),
(3, 'Dulex', '2', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 8500, 'No'),
(4, 'Dulex', '2', 'Yes', 'Yes', 'No', 'Yes', 'Yes', 8500, 'No'),
(5, 'Two-Bedroom Suite', '4', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 15200, 'No'),
(6, 'Two-Bedroom Suite', '4', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 15200, 'No'),
(7, 'Semi', '2', 'Yes', 'Yes', 'No', 'No', 'No', 3500, 'Yes'),
(8, 'Luxury', '3', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 13500, 'No'),
(9, 'Semi', '2', 'Yes', 'Yes', 'No', 'Yes', 'No', 4500, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `telephone` int(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `name`, `address`, `email`, `telephone`, `user_name`, `password`, `type`) VALUES
(1, 'sasi', 'panadura', 'sasi@gmail.com', 786787651, 'sasi', '123', 'Admin'),
(2, 'sunil', 'ganemulla', 'sunil@gmail.com', 789876780, 'sunil', 'aaa', 'Receiptionist'),
(3, 'minindu', 'kottawa', 'mini@gmail.com', 768978909, 'mini', 'small', 'Admin'),
(4, 'Dulmi', 'Homagama', 'dulmi@gmail.com', 112546853, 'dul', 'dul', 'Receiptionist'),
(5, 'Amal', 'galle', 'amal@gmail.com', 778564250, 'amal', 'amal', 'Receiptionist'),
(6, 'kamal', 'mathara', 'kamal@gmail.com', 112536475, 'kamal', 'kamal', 'Receiptionist'),
(7, 'Nirosh', 'mirissa', 'niro@gmail.com', 772188365, 'nirosh', 'nirosh', 'Receiptionist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`contact_no`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_no`);

--
-- Indexes for table `food_items`
--
ALTER TABLE `food_items`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `food_order`
--
ALTER TABLE `food_order`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `b_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_no` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `food_items`
--
ALTER TABLE `food_items`
  MODIFY `i_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `food_order`
--
ALTER TABLE `food_order`
  MODIFY `o_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `r_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=760256941;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
